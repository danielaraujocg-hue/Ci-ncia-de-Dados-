# Predição de comparecimento às teleconsultas do SUS no Rio de Janeiro

Projeto da disciplina **IND2622 – Ciência de Dados para Processos de Negócios (PUC-Rio)**.
Autores: Adriana Nascimento, Daniel Araújo e Felipe Abuzed.

O projeto estima a chance de uma pessoa comparecer a uma teleconsulta agendada na Atenção Primária do município do Rio de Janeiro e transforma essa previsão em ação: uma lista de prioridade para a Clínica da Família e o envio de lembretes por WhatsApp, SMS e e-mail.

---

## Perguntas do estudo

| Questão | Pergunta |
| --- | --- |
| Q1 | Qual o perfil sociodemográfico e territorial de quem comparece à teleconsulta? |
| Q2 | O comparecimento muda conforme a classe e a renda do bairro de residência? |
| Q3 | Quais variáveis têm maior peso na previsão e quais perfis têm mais e menos chance de comparecer? |

## Principais resultados

- Base: 21.363 agendamentos (26,8% compareceram). Alvo: compareceu × não compareceu (falta ou cancelamento pelo paciente).
- Modelo recomendado: **XGBoost** com o conjunto de variáveis **C2** (sexo, raça/cor, faixa etária, região de residência, classe ABEP e renda média do bairro).
  - Teste (20% mais recentes): **AUC 0,913** (IC 95%: 0,901 a 0,924), PR-AUC 0,876, recall 76,1%, acurácia 90,3%.
- Valores SHAP: o **território** (renda média do bairro, região e classe) responde por cerca de **92%** da contribuição; sexo, raça/cor e idade, por cerca de 8%.
- Teste em um dia real (9/6/2026, 121 agendamentos): o modelo previu 35 comparecimentos e vieram 34; das 84 pessoas classificadas com baixa chance, só 2 compareceram.

> O peso do território indica contribuição para a previsão, não causa. A base não traz antecedência do agendamento nem histórico de faltas, os preditores mais frequentes na literatura.

---

## Estrutura do repositório

```
teleconsultas-sus-rj/
├── estudo_comparecimento_final.py   # estudo completo: tratamento, conjuntos C1–C4, 3 modelos, validação, SHAP, pós-processamento
├── prever_agenda.py                 # uso na rotina: lista de prioridade e envio de lembretes
├── config_envio.exemplo.json        # modelo de configuração das contas de envio (sem senhas)
├── exemplos/
│   └── agenda_ficticia.xlsx         # agenda 100% fictícia para teste
├── requirements.txt
├── LICENSE
└── README.md
```

## Dados

**Os dados não estão neste repositório.** A base de agendamentos pertence à Secretaria Municipal de Saúde do Rio de Janeiro (SMS-RJ) e contém registros individuais. Por isso, não pode ser publicada (Lei Geral de Proteção de Dados – LGPD). Quem tiver autorização deve colocar a planilha na pasta do projeto com o nome definido em `CAMINHO_PLANILHA` (Etapa 0 do estudo), com a aba `Base final tratada`.

O arquivo `exemplos/agenda_ficticia.xlsx` foi gerado aleatoriamente: os nomes de bairros são públicos, mas pessoas, datas, telefones e e-mails são inventados.

---

## Instalação

Requer Python 3.10 ou superior.

```bash
git clone https://github.com/felipeaafernandes81-afk/teleconsultas-sus-rj.git
cd teleconsultas-sus-rj
python -m venv .venv
# Windows: .venv\Scripts\activate   |   Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt
```

## 1. Rodar o estudo

```bash
python estudo_comparecimento_final.py
```

Saídas em `resultados_final/`:
- `resultados_comparecimento_final.xlsx`: todas as tabelas, cada aba com legenda (o que é, por que, como ler);
- gráficos (`G1` a `G6`);
- `modelo_comparecimento.joblib`: o modelo final, usado pelo `prever_agenda.py`.

No fim da execução, o resumo dos resultados aparece na tela.

## 2. Usar na Clínica da Família

```bash
# simulação (padrão): mostra o que seria enviado, sem enviar
python prever_agenda.py agenda.xlsx 40

# envio real pelas contas configuradas
python prever_agenda.py agenda.xlsx 40 --enviar
```

- `agenda.xlsx`: agenda dos próximos dias, exportada do sistema de agendamento.
  - Colunas obrigatórias: `sexo`, `raca_cor`, `Faixa etária` e `bairro_residencia`.
  - Colunas recomendadas: `dthr_marcacao`, `telefone`, `email`, `aceita_mensagens` e `ID`.
- `40`: quantas ligações a equipe consegue fazer.
- `--hoje AAAA-MM-DD`: simula outra data de referência (útil para teste).

Teste com a agenda fictícia (é preciso ter gerado o modelo no passo 1):

```bash
python prever_agenda.py exemplos/agenda_ficticia.xlsx 10 --hoje 2026-11-30
```

Saída: `lista_prioridade.xlsx`, com as abas:

| Aba | Conteúdo |
| --- | --- |
| `lista_de_prioridade` | Cada agendamento com chance de comparecer, faixa, ação sugerida, mensagem e motivo (SHAP), da menor para a maior chance |
| `ligacoes_ACS` | Agendamentos de baixa chance, na ordem em que os agentes comunitários devem ligar |
| `envios` | Registro de cada mensagem (simulada, enviada, sem contato, sem consentimento ou erro) |
| `resumo_da_agenda` | Comparecimentos esperados (Σ p), ausências esperadas (Σ (1 − p)) e precisão dos contatos |
| `legenda` | Significado de cada campo |

### Regras de decisão

| Faixa | Chance de comparecer | Mensagens automáticas | Equipe |
| --- | --- | --- | --- |
| Baixa | menor que 20% | WhatsApp/SMS e e-mail, 3 dias e 1 dia antes | ligação do ACS se não confirmar; oferecer remarcação ou teleconsulta assistida na unidade |
| Média | de 20% a 50% | WhatsApp/SMS e e-mail, 1 dia antes | ajuda para abrir o link, se pedida |
| Alta | 50% ou mais | WhatsApp/SMS, 1 dia antes | – |

Os limites (`LIMIARES`) e as ações (`ACOES`) ficam no estudo; os dias e canais de envio (`DIAS_ENVIO`, `CANAIS`) ficam no `prever_agenda.py`. Todos podem ser ajustados à capacidade da equipe.

### Configurar o envio (uma única vez por unidade)

1. Copie `config_envio.exemplo.json` para `config_envio.json`.
2. Preencha os dados das contas autorizadas pela SMS-RJ:
   - WhatsApp Business (API da Meta, com um modelo de mensagem aprovado);
   - serviço de SMS;
   - e-mail institucional (SMTP).
3. Mude `"ativo"` para `true` nos canais contratados.
4. Guarde senhas e tokens em variáveis de ambiente (`WHATSAPP_TOKEN`, `SMS_TOKEN`, `EMAIL_SENHA`), nunca no arquivo.

O `config_envio.json` está no `.gitignore` e não deve ser publicado.

---

## Uso responsável

- **Finalidade:** a previsão serve para **oferecer apoio** aos pacientes, nunca para negar ou reduzir vagas. Os territórios de menor chance concentram bairros mais pobres.
- **Consentimento:** só recebe mensagem quem aceitou (coluna `aceita_mensagens`).
- **Atualização:** o modelo deve ser retreinado periodicamente, porque o padrão de comparecimento muda com o tempo. Uma boa forma de acompanhar é comparar todo mês os comparecimentos previstos com os reais.

## Referências principais

- LUNDBERG, S. M.; LEE, S.-I. A unified approach to interpreting model predictions. *NeurIPS*, 2017.
- LUNDBERG, S. M. et al. From local explanations to global understanding with explainable AI for trees. *Nature Machine Intelligence*, v. 2, p. 56-67, 2020.
- DANTAS, L. F. et al. No-shows in appointment scheduling – a systematic literature review. *Health Policy*, v. 122, n. 4, p. 412-421, 2018.
- GUROL-URGANCI, I. et al. Mobile phone messaging reminders for attendance at healthcare appointments. *Cochrane Database of Systematic Reviews*, CD007458, 2013.
- SHAH, S. J. et al. Targeted reminder phone calls to patients at high risk of no-show visits: a randomized trial. *Journal of General Internal Medicine*, v. 31, n. 12, p. 1460-1466, 2016.

## Licença

Código sob licença MIT (ver `LICENSE`). Os dados da SMS-RJ não fazem parte do repositório e seguem as regras da Secretaria.
