# =============================================================================
# prever_agenda.py – Lista de prioridade e envio de lembretes de teleconsulta
# PUC-Rio, IND2622 – Adriana Nascimento, Daniel Araújo, Felipe Abuzed
#
# Uso:
#   python prever_agenda.py agenda.xlsx [capacidade_de_ligacoes] [--enviar] [--hoje AAAA-MM-DD]
#   Sem --enviar, o programa roda em MODO SIMULAÇÃO: mostra e registra o que seria enviado, sem enviar.
#   Com --enviar, envia de fato pelos canais ativados em config_envio.json.
#
# Entrada (agenda): planilha xlsx ou csv com as colunas da base tratada
#   obrigatórias: sexo, raca_cor, Faixa etária, bairro_residencia
#   recomendadas: dthr_marcacao (data e hora da teleconsulta), telefone, email, aceita_mensagens (sim/não), ID
#
# Saída: lista_prioridade.xlsx com as abas lista_de_prioridade, ligacoes_ACS, envios, resumo_da_agenda e legenda.
#
# Configuração do envio (uma única vez por unidade): config_envio.json, com as contas de WhatsApp Business,
# SMS e e-mail autorizadas pela SMS-RJ. Senhas e tokens ficam em variáveis de ambiente, nunca no arquivo.
# Requer: modelo_comparecimento.joblib, gerado por estudo_comparecimento_final.py.
# =============================================================================
import argparse, base64, json, os, re, smtplib, ssl, sys, time, unicodedata, urllib.parse, urllib.request
from email.message import EmailMessage
import numpy as np
import pandas as pd
import joblib
import shap

ARQ_MODELO = next((a for a in ["resultados_final/modelo_comparecimento.joblib", "modelo_comparecimento.joblib"]
                   if os.path.exists(a)), "resultados_final/modelo_comparecimento.joblib")
NOMES = {"Faixa etária": "faixa_etaria", "bairro_residencia": "bairro", "Classe associada": "classe",
         "Região (trazer via tabela de-para área programática ou bairro de residência?)": "regiao_residencia",
         "Região de residência": "regiao_residencia",
         "Renda média por família (nova base para cruzar)": "renda_media", "Renda média": "renda_media",
         "Região de atendimento": "regiao_atendimento"}

# Texto enviado por WhatsApp, SMS ou e-mail (a data e o horário entram quando a agenda traz dthr_marcacao)
MENSAGEM = ("Olá! Você tem uma teleconsulta marcada na sua Clínica da Família{quando}. "
            "Responda 1 para confirmar ou 2 para remarcar. Se preferir, a consulta pode ser feita na própria unidade.")
ASSUNTO = "Lembrete da sua teleconsulta – Clínica da Família"
# Quantos dias antes da consulta cada faixa recebe mensagem, e por quais canais
DIAS_ENVIO = {"Baixa chance": [3, 1], "Média chance": [1], "Alta chance": [1]}
CANAIS = {"Baixa chance": ["whatsapp_ou_sms", "email"], "Média chance": ["whatsapp_ou_sms", "email"],
          "Alta chance": ["whatsapp_ou_sms"]}


def norm(s):
    if pd.isna(s):
        return None
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", s).strip()


# ----------------------------------------------------------------------------- previsão
def carregar_agenda(caminho):
    df = pd.read_csv(caminho, sep=None, engine="python") if caminho.endswith(".csv") else pd.read_excel(caminho)
    df = df.rename(columns=NOMES)
    faltando = [c for c in ["sexo", "raca_cor", "faixa_etaria", "bairro"] if c not in df]
    if faltando:
        sys.exit(f"Colunas obrigatórias ausentes na agenda: {faltando}")
    if "dthr_marcacao" in df:
        df["dthr_marcacao"] = pd.to_datetime(df["dthr_marcacao"], errors="coerce")
    return df


def completar_territorio(df, pacote):
    """Preenche região, classe e renda média a partir do bairro, quando não vierem na agenda."""
    ref = pacote["ref_bairro"]
    for c in ["regiao_residencia", "classe", "renda_media", "regiao_atendimento"]:
        if c not in df:
            df[c] = np.nan
    for c in ["regiao_residencia", "classe", "regiao_atendimento"]:
        df[c] = df[c].astype("object")
    chave = df["bairro"].map(norm)
    for c in ["regiao_residencia", "classe", "renda_media"]:
        vazio = df[c].isna()
        df.loc[vazio, c] = chave[vazio].map(lambda k: ref.loc[k, c] if k in ref.index else np.nan)
    for c in ["regiao_residencia", "classe"]:
        df[c] = df[c].fillna(pacote["na"])
    df["renda_media"] = pd.to_numeric(df["renda_media"], errors="coerce")
    return df


def prever(df, pacote):
    base, iso, cols = pacote["base"], pacote["iso"], pacote["colunas"]
    nota = base.predict_proba(df[cols])[:, 1]                    # s = f(x)
    p = nota if iso is None else iso.predict(nota)               # chance de comparecer
    lim, acoes = pacote["limiares"], pacote["acoes"]
    faixa = np.where(p < lim["baixa"], "Baixa chance", np.where(p < lim["alta"], "Média chance", "Alta chance"))
    # motivo: as duas variáveis com maior valor SHAP absoluto
    modelo = base.named_steps["modelo"]
    X = base.named_steps["prep"].transform(df[cols])
    expl = shap.TreeExplainer(modelo) if hasattr(modelo, "get_booster") or hasattr(modelo, "estimators_") \
        else shap.LinearExplainer(modelo, X)
    sv = expl.shap_values(X)
    sv = sv[1] if isinstance(sv, list) else (sv[:, :, 1] if np.ndim(sv) == 3 else sv)
    agg = pd.DataFrame(sv, columns=pacote["var_prod"]).T.groupby(level=0).sum().T
    motivos = []
    for i in range(len(df)):
        linha, partes = agg.iloc[i], []
        for c in linha.abs().sort_values(ascending=False).index[:2]:
            v = df.iloc[i][c]
            valor = f"R$ {v:,.0f}".replace(",", ".") if c == "renda_media" and pd.notna(v) else str(v)
            partes.append(f"{pacote['rot'][c]} = {valor} ({'aumenta' if linha[c] > 0 else 'reduz'} a chance)")
        motivos.append("; ".join(partes))
    out = df.copy()
    out["chance de comparecer"] = p.round(3)
    out["faixa"] = faixa
    out["ação sugerida"] = pd.Series(faixa, index=df.index).map(acoes)
    out["motivo principal"] = motivos
    out["prioridade"] = pd.Series(p + nota * 1e-6, index=df.index).rank(method="first").astype(int)
    quando = (df["dthr_marcacao"].dt.strftime(" em %d/%m às %Hh%M").fillna("")
              if "dthr_marcacao" in df else pd.Series("", index=df.index))
    out["mensagem (WhatsApp/SMS/e-mail)"] = [MENSAGEM.format(quando=q) for q in quando]
    out["_quando"] = quando.str.replace(" em ", "", regex=False)
    return out.sort_values("prioridade")


def resumo(lista, capacidade=None):
    p = lista["chance de comparecer"].astype(float); n = len(lista)
    k = min(n, capacidade if capacidade is not None else int((lista["faixa"] == "Baixa chance").sum()))
    sel = lista.nsmallest(k, "chance de comparecer")
    aus_tot, aus_k = (1 - p).sum(), (1 - sel["chance de comparecer"]).sum()
    return pd.DataFrame([
        ("Agendamentos na agenda (n)", n),
        ("Comparecimentos esperados (Σ p)", round(p.sum(), 1)),
        ("Ausências esperadas (Σ (1 − p))", round(aus_tot, 1)),
        ("Agendamentos de baixa chance", int((lista["faixa"] == "Baixa chance").sum())),
        ("Contatos planejados (k)", k),
        ("Ausências esperadas entre os contatados (A_k)", round(float(aus_k), 1)),
        ("Precisão esperada dos contatos (A_k ÷ k)", f"{aus_k / k:.1%}".replace(".", ",") if k else "–"),
        ("Ausências da agenda alcançadas (A_k ÷ Σ(1 − p))", f"{aus_k / aus_tot:.1%}".replace(".", ",") if aus_tot else "–"),
    ], columns=["indicador", "valor"])


# ----------------------------------------------------------------------------- envio
def _post(url, dados=None, corpo_json=None, cabecalhos=None):
    corpo = json.dumps(corpo_json).encode() if corpo_json is not None else urllib.parse.urlencode(dados).encode()
    req = urllib.request.Request(url, data=corpo, headers=cabecalhos or {}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status


def enviar_whatsapp(cfg, telefone, quando):
    """WhatsApp Business (API oficial da Meta). Usa um modelo de mensagem aprovado, com a data e a hora como parâmetro."""
    c = cfg["whatsapp"]
    url = f"https://graph.facebook.com/{c.get('versao_api', 'v19.0')}/{c['phone_number_id']}/messages"
    corpo = {"messaging_product": "whatsapp", "to": re.sub(r"\D", "", str(telefone)), "type": "template",
             "template": {"name": c["modelo_mensagem"], "language": {"code": "pt_BR"},
                          "components": [{"type": "body", "parameters": [{"type": "text", "text": quando or "data agendada"}]}]}}
    return _post(url, corpo_json=corpo, cabecalhos={"Authorization": f"Bearer {os.environ.get(c['token_env'], '')}",
                                                    "Content-Type": "application/json"})


def enviar_sms(cfg, telefone, texto):
    """SMS pela API da Twilio (pode ser trocada por outro provedor contratado pela SMS-RJ)."""
    c = cfg["sms"]; sid = c["account_sid"]
    aut = base64.b64encode(f"{sid}:{os.environ.get(c['token_env'], '')}".encode()).decode()
    return _post(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
                 dados={"To": str(telefone), "From": c["numero_origem"], "Body": texto},
                 cabecalhos={"Authorization": f"Basic {aut}"})


def enviar_email(cfg, destino, texto):
    """E-mail pelo servidor SMTP da unidade."""
    c = cfg["email"]
    m = EmailMessage(); m["Subject"] = c.get("assunto", ASSUNTO); m["From"] = c["remetente"]; m["To"] = destino
    m.set_content(texto)
    with smtplib.SMTP(c["servidor"], c.get("porta", 587), timeout=20) as s:
        s.starttls(context=ssl.create_default_context())
        s.login(c["usuario"], os.environ.get(c["senha_env"], ""))
        s.send_message(m)
    return 250


def mascarar(destino):
    d = str(destino)
    return ("***" + d[-4:]) if "@" not in d else (d[0] + "***@" + d.split("@")[1])


def ativo(cfg, canal):
    return bool(cfg and cfg.get(canal, {}).get("ativo"))


def disparar(lista, config, enviar=False, hoje=None):
    """Envia (ou simula) os lembretes do dia: cada faixa recebe nos dias definidos em DIAS_ENVIO, pelos canais de CANAIS."""
    hoje = pd.Timestamp(hoje or pd.Timestamp.now()).normalize()
    pausa = (config or {}).get("pausa_segundos", 1)
    log = []
    for _, r in lista.iterrows():
        dias = None
        if "dthr_marcacao" in r and pd.notna(r["dthr_marcacao"]):
            dias = (r["dthr_marcacao"].normalize() - hoje).days
            if dias not in DIAS_ENVIO[r["faixa"]]:
                continue
        base = {"prioridade": r["prioridade"], "ID": r.get("ID", ""), "faixa": r["faixa"], "dias até a consulta": dias}
        if str(r.get("aceita_mensagens", "sim")).strip().lower() in ("não", "nao", "n", "false", "0"):
            log.append({**base, "canal": "–", "destino": "–", "status": "sem consentimento (não enviado)"})
            continue
        for canal in CANAIS[r["faixa"]]:
            if canal == "email":
                destino, nome_canal = r.get("email"), "e-mail"
                usar = ativo(config, "email")
            else:
                destino = r.get("telefone")
                nome_canal = "WhatsApp" if ativo(config, "whatsapp") or not ativo(config, "sms") else "SMS"
                usar = ativo(config, "whatsapp") or ativo(config, "sms")
            if destino is None or pd.isna(destino) or str(destino).strip() == "":
                status = "sem contato na agenda"
            elif not enviar:
                status = "simulado (use --enviar para enviar)"
            elif not usar:
                status = "canal não configurado em config_envio.json"
            else:
                try:
                    if nome_canal == "e-mail":
                        enviar_email(config, destino, r["mensagem (WhatsApp/SMS/e-mail)"])
                    elif nome_canal == "WhatsApp":
                        enviar_whatsapp(config, destino, r["_quando"])
                    else:
                        enviar_sms(config, destino, r["mensagem (WhatsApp/SMS/e-mail)"])
                    status = "enviado"
                    time.sleep(pausa)
                except Exception as e:                            # registra a falha e segue para o próximo
                    status = f"erro: {e}"
            log.append({**base, "canal": nome_canal, "destino": mascarar(destino) if status != "sem contato na agenda" else "–",
                        "status": status, "horário": pd.Timestamp.now().strftime("%d/%m/%Y %H:%M")})
    return pd.DataFrame(log)


# ----------------------------------------------------------------------------- execução
if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Lista de prioridade e envio de lembretes de teleconsulta")
    ap.add_argument("agenda"); ap.add_argument("capacidade", nargs="?", type=int, default=None)
    ap.add_argument("--enviar", action="store_true", help="envia de fato (sem esta opção, apenas simula)")
    ap.add_argument("--config", default="config_envio.json"); ap.add_argument("--hoje", default=None, help="data de referência AAAA-MM-DD")
    args = ap.parse_args()
    pacote = joblib.load(ARQ_MODELO)
    config = json.load(open(args.config, encoding="utf-8")) if os.path.exists(args.config) else None
    hoje = args.hoje
    agenda = completar_territorio(carregar_agenda(args.agenda), pacote)
    lista = prever(agenda, pacote)
    tab_resumo = resumo(lista, args.capacidade)
    log = disparar(lista, config, enviar=args.enviar, hoje=hoje)    # WhatsApp/SMS e e-mail no dia certo de cada faixa
    ligacoes = lista[lista["faixa"] == "Baixa chance"].head(args.capacidade or len(lista))
    colunas = [c for c in ["prioridade", "ID", "dthr_marcacao", "sexo", "raca_cor", "faixa_etaria", "bairro", "regiao_residencia",
                           "telefone", "chance de comparecer", "faixa", "ação sugerida", "mensagem (WhatsApp/SMS/e-mail)",
                           "motivo principal"] if c in lista]
    n_msg = int((log["canal"] != "–").sum()) if len(log) else 0
    with pd.ExcelWriter("lista_prioridade.xlsx") as w:
        lista[colunas].to_excel(w, sheet_name="lista_de_prioridade", index=False)
        ligacoes[[c for c in ["prioridade", "ID", "dthr_marcacao", "telefone", "bairro", "chance de comparecer", "ação sugerida"]
                  if c in ligacoes]].to_excel(w, sheet_name="ligacoes_ACS", index=False)
        (log if len(log) else pd.DataFrame(columns=["status"])).to_excel(w, sheet_name="envios", index=False)
        tab_resumo.to_excel(w, sheet_name="resumo_da_agenda", index=False)
        pd.DataFrame([
            ("Chance de comparecer", "Probabilidade de a pessoa comparecer (0 a 1), dada pelo modelo; no teste ficou próxima da taxa real."),
            ("Faixa", f"Baixa se chance < {pacote['limiares']['baixa']:.0%}; Média até {pacote['limiares']['alta']:.0%}; Alta acima."),
            ("Ação sugerida", "O que a equipe faz conforme a faixa."),
            ("Mensagem", "Texto enviado por WhatsApp, SMS ou e-mail, com data e horário da teleconsulta."),
            ("Envios", "Baixa chance: 3 dias e 1 dia antes; média e alta: 1 dia antes. Quem não aceitou mensagens não recebe."),
            ("Ligações ACS", "Agendamentos de baixa chance, na ordem de prioridade, para ligação de quem não confirmar."),
            ("Motivo principal", "As duas características que mais puxaram a chance para cima ou para baixo (valores SHAP)."),
            ("Prioridade", "Ordem de contato: 1 = menor chance de comparecer."),
            ("Modelo", f"{pacote['modelo']}, conjunto {pacote['conjunto']}, treinado com dados até {pacote['treinado_ate']}."),
        ], columns=["campo", "significado"]).to_excel(w, sheet_name="legenda", index=False)
    print(tab_resumo.to_string(index=False))
    modo = "ENVIO REAL" if args.enviar else "SIMULAÇÃO"
    print(f"\nMensagens de hoje ({modo}): {n_msg} | ligações para os ACS: {len(ligacoes)}")
    if len(log):
        print(log.groupby(["canal", "status"]).size().to_string())
    print(f"\nLista salva em lista_prioridade.xlsx ({len(lista)} agendamentos).")
